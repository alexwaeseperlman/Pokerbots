while True:
    s = input()
    if s == 'ping':
        print('pong')
    else:
        print('no')
