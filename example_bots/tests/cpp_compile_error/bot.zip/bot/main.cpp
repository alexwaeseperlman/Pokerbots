int main() {
  this is a compiler error;
}