# Problem-Setting-Resources
Resources for Problem Setters

I believe in free and unrestricted resources to ensure problem setters have correct data

- Validator in C++ and Java including whitespace
- C++ Standard Checker, Standard Interactor, Identical Checker, Identical Interactor
- C++ file all include `Input.h`
