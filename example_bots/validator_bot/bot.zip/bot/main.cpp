#include <iostream>
#include <vector>
#include "Problem-Setting-Resources/Input.h"
using namespace std;

int main() {
  while (true) {
  }
}