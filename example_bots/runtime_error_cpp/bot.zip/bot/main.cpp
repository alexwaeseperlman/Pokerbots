#include <cassert>
#include <iostream>
using namespace std;

int main() {
  assert(false);
}